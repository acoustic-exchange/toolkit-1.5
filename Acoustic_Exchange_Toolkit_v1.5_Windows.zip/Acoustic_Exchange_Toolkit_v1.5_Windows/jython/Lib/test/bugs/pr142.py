print type(KeyError())
