from metaclass import NoOpMetaClass
class TestClass(object):
    __metaclass__ = NoOpMetaClass
