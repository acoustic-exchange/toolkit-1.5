class Foobar(object):
    pass
