-----------------------------------------------------------------------------
-- Copyright (C) 2018, 2020 Acoustic, L.P. All rights reserved.  
-- NOTICE: This file contains material that is confidential and proprietary to
-- Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
-- industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
-- Acoustic, L.P. Any unauthorized copying or distribution of content from this file is prohibited.
-----------------------------------------------------------------------------
CREATE TABLE UBX_EmailSend (
	RecordID		bigint NOT NULL GENERATED ALWAYS AS IDENTITY,
	Provider		varchar(64),
	EndpointSource	varchar(64),
	Channel			varchar(64),
	X1ID			varchar(64),
	ContactId		varchar(64),
	Email			varchar(64),
	EventCode		varchar(64) NOT NULL,
	EventTimeStamp	timestamp NOT NULL,
	EventNameSpace	varchar(64),
	EventVersion	varchar(64),			
	EventName		varchar(64),
	Description		varchar(128),
	MessageId		bigint,
	MailingTemplateId bigint,
	ReportId		varchar(64),	
	SubjectLine 	varchar(256),
	MessageName 	varchar(256),
	DocType	    	varchar(64),
	SendType    	varchar(64),
	EventId     	varchar(64),
    CONSTRAINT tUBX_EmailSend_PK PRIMARY KEY (RecordID)
);

CREATE TABLE UBX_EmailOpen (
	RecordID		bigint NOT NULL GENERATED ALWAYS AS IDENTITY,
	Provider		varchar(64),
	EndpointSource	varchar(64),
	Channel			varchar(64),
	X1ID			varchar(64),
	ContactId		varchar(64),
	Email			varchar(64),
	EventCode		varchar(64) NOT NULL,
	EventTimeStamp	timestamp NOT NULL,
	EventNameSpace	varchar(64),
	EventVersion	varchar(64),				
	EventName		varchar(64),
	Description		varchar(128),
	MessageId		bigint,
	MailingTemplateId bigint,
	ReportId		varchar(64),	
	SubjectLine 	varchar(256),
	MessageName 	varchar(256),
	DocType	    	varchar(64),
	EventId     	varchar(64),
    CONSTRAINT tUBX_EmailOpen_PK PRIMARY KEY (RecordID)
);

CREATE TABLE UBX_EmailClick (
	RecordID		bigint NOT NULL GENERATED ALWAYS AS IDENTITY,
	Provider		varchar(64),
	EndpointSource	varchar(64),
	Channel			varchar(64),
	X1ID			varchar(64),
	ContactId		varchar(64),
	Email			varchar(64),
	EventCode		varchar(64) NOT NULL,
	EventTimeStamp	timestamp NOT NULL,
	EventNameSpace	varchar(64),
	EventVersion	varchar(64),
	EventName		varchar(64),
	Description		varchar(128),
	MessageId		bigint,
	MailingTemplateId bigint,
	ReportId		varchar(64),	
	SubjectLine 	varchar(256),
	MessageName 	varchar(256),
	DocType	    	varchar(64),
	ClickUrl	   	varchar(128),
	UrlDescription 	varchar(128),
	EventId     	varchar(64),
    CONSTRAINT tUBX_EmailClick_PK PRIMARY KEY (RecordID)
);

CREATE TABLE UBX_EmailBounce (
	RecordID		bigint NOT NULL GENERATED ALWAYS AS IDENTITY,
	Provider		varchar(64),
	EndpointSource	varchar(64),
	Channel			varchar(64),
	X1ID			varchar(64),
	ContactId		varchar(64),
	Email			varchar(64),
	EventCode		varchar(64) NOT NULL,
	EventTimeStamp	timestamp NOT NULL,
	EventNameSpace	varchar(64),
	EventVersion	varchar(64),					
	EventName		varchar(64),
	Description		varchar(128),
	MessageId		bigint,
	MailingTemplateId bigint,
	ReportId		varchar(64),	
	SubjectLine 	varchar(256),
	MessageName 	varchar(256),
	DocType	    	varchar(64),
	BounceType    	varchar(64),
	EventId     	varchar(64),
    CONSTRAINT tUBX_EmailBounce_PK PRIMARY KEY (RecordID)
);
  
