package javatests;

import java.math.BigDecimal;

public class BigDecimalTest {
    public static BigDecimal asBigDecimal() {
	return new BigDecimal("123.4321");
    }
}

