package org.python.tests.multihidden;

public interface SpecialConnection {
    String close(int foo);
}
