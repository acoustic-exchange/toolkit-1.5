package org.python.tests.identity;

public class IdentityObject {

    public IdentityObject() {
    }
    
    public IdentityObject getThis() {
        return this;
    }

}
