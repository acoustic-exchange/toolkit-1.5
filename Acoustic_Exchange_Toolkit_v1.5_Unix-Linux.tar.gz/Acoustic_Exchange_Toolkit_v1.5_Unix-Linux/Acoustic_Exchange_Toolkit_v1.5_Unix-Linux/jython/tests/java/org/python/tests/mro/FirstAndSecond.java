package org.python.tests.mro;

public interface FirstAndSecond extends FirstPredefinedGetitem, SecondPredefinedGetitem {}
