##################################################################################
#   Copyright (C) 2018, 2020 Acoustic, L.P. All rights reserved.  
#   NOTICE: This file contains material that is confidential and proprietary to
#   Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
#   industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
#   Acoustic, L.P. Any unauthorized copying or distribution of content from this file is prohibited.

##################################################################################
import os
import sys
import getopt
import time

from conf.cfg import getAbsolutePath
from conf.ubxconfig import UBXConfig
from ubx.apimanager import UBXAPIManager
from ubx.segments import *
from ubx.jobs import *

from com.ibm.emm.integration.log import CSLogger
from java.lang import Exception, Throwable

def DownloadSegments(argv):    

    # Parsing command line arguments                
    configPropsFileName = None
       
    usage = 'Usage: downloadSegments [-c <config properties file>]'    
    try:
        opts, args = getopt.getopt(argv,"hc:",["config="])
    except getopt.GetoptError:
        print usage
        sys.exit(64)
    for opt, arg in opts:        
        if opt in ("-c", "--config"):
            configPropsFileName = getAbsolutePath(arg)
    
    try:       
        # Initializing, loading configuration, etc.
        csLogger = CSLogger.setScript("downloadSegments")
        csLogger = CSLogger.getCSLogger("scripts.downloadSegments")        
        csLogger.info("***** Download Audiences script started. *****")  
        
        config = UBXConfig(configPropsFileName)
        authkey = config.getSegmentConsumerAuthenticationKey()
        
        apimanager = UBXAPIManager(config)
        
        # Get list of jobs ready for download
        jobs = apimanager.getJobs(authkey, JobCategory.SEGMENT_EXPORT, config.getSegmentConsumerEndpointID(), JobStatus.READY_FOR_DOWNLOAD,True)
        if (jobs is not None):  
            csLogger.info("Number of audiences to be downloaded: " + str(len(jobs)))
            
        i = 1
        if (jobs is not None):        
            for job in jobs:
                csLogger.info("Downloading audience " + str(i) + ": " + job.destinationSegmentName)                
                if (len(job.segmentDataFiles) > 0):
                    try:
                        csLogger.info("Number of files for audience: " + str(len(job.segmentDataFiles)))
                        apimanager.downloadSegmentData(job)
                        apimanager.setJobStatus(config.getSegmentConsumerAuthenticationKey(), job.jobId, JobStatus.COMPLETE)         
                    except IOError, ioe:
                        csLogger.error("Segment consumer endpoint ID :" + config.getSegmentConsumerEndpointID() + " " +str(ioe))       
                    except Exception, e:
                        csLogger.error("Segment consumer endpoint ID :" + config.getSegmentConsumerEndpointID() + " " + str(e))
                else:
                    csLogger.error("Segment consumer endpoint ID :" + config.getSegmentConsumerEndpointID() + " No audience files found for: " + job.destinationSegmentName)
                i = i + 1
    except Throwable, e:
        csLogger.error("Segment consumer endpoint ID :" + config.getSegmentConsumerEndpointID() + " Download Audiences script terminating with error! " , e)                                         
    
    except BaseException, e:
        csLogger.error("Segment consumer endpoint ID :" + config.getSegmentConsumerEndpointID() + " Download Audiences script terminating with error! " + str(e))
            
    finally:
        csLogger.info("***** Download Audiences script completed. *****")  

if __name__ == '__main__':    
    DownloadSegments(sys.argv[1:])
