issue1811 = __import__('test.issue1811', globals(), locals(), ['foo'])
