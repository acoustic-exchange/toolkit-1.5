package org.python.tests.mro;

public interface PostAndFirst extends PostdefinedGetitem, FirstPredefinedGetitem {}
