package org.python.tests.inbred;

public interface Metis extends Zeus {}
