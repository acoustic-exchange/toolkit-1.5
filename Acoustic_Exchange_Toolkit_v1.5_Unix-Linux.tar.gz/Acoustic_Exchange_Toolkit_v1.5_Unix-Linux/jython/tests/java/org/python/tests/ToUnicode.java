package org.python.tests;

public class ToUnicode {

    @Override
    public String toString() {
        return "Circle is 360\u00B0";
    }
}
