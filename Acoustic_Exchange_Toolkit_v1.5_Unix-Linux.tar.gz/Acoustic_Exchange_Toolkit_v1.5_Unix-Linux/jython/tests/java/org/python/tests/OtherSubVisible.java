package org.python.tests;

/** An extension of Visible that's not SubVisible for use in test_java_visibility.CoercionTest */
public class OtherSubVisible extends Visible {}
