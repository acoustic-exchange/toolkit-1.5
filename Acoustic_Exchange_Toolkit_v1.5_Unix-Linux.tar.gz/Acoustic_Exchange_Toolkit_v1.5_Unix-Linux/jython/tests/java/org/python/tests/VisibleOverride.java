package org.python.tests;


public interface VisibleOverride {
    
    public int visibleInstance(double val, String oval);
}
