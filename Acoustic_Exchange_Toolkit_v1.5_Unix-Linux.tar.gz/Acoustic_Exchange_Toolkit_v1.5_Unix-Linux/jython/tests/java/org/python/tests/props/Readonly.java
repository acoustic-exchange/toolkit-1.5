package org.python.tests.props;

public class Readonly {
    private String a;
    public void setA(String a) { this.a = a; }
}

