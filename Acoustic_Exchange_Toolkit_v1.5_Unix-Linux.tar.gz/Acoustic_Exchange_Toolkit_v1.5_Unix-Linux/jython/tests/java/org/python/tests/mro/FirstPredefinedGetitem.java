package org.python.tests.mro;

public interface FirstPredefinedGetitem {}
