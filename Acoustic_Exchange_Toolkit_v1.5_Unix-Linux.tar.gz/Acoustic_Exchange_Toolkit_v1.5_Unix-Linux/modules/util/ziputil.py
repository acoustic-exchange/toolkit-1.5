##################################################################################
#   Copyright (C) 2018, 2020 Acoustic, L.P. All rights reserved.  
#   NOTICE: This file contains material that is confidential and proprietary to
#   Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
#   industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
#   Acoustic, L.P. Any unauthorized copying or distribution of content from this file is prohibited.

##################################################################################
import gzip
import zipfile
import os

def unzip(zipfilepath, destfolder, logger=None):
    zfile = zipfile.ZipFile(zipfilepath)
    for name in zfile.namelist():
        (dirname, filename) = os.path.split(name)
        if (logger is not None):
            logger.debug("Decompressing " + filename + " to " + destfolder)
        if not os.path.exists(destfolder):
            os.makedirs(destfolder)
        outfilepath = destfolder + os.sep + filename
        outfile = open(outfilepath, "wb")
        outfile.write(zfile.read(name))
        outfile.close()
    zfile.close()
    zfile = None

def gunzip(zipfilepath, destfolder, logger=None):
    zfile = gzip.open(zipfilepath, 'rb')
    (dirname, filename) = os.path.split(zipfilepath)
    name = os.path.splitext(filename)[0]
    if (logger is not None):
         logger.debug("Decompressing " + name + " to " + destfolder)
    if not os.path.exists(destfolder):
         os.makedirs(destfolder)
    outfilepath = destfolder + os.sep + name
    outfile = open(outfilepath, "wb")
    outfile.write(zfile.read())
    outfile.close()
    zfile.close()
    zfile = None
