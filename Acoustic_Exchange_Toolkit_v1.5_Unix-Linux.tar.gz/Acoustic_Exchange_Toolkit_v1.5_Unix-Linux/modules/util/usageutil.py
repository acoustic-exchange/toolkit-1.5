##################################################################################
#   Copyright (C) 2018, 2020 Acoustic, L.P. All rights reserved.  
#   NOTICE: This file contains material that is confidential and proprietary to
#   Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
#   industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
#   Acoustic, L.P. Any unauthorized copying or distribution of content from this file is prohibited.

##################################################################################


def referToCommandLineHelp():
    print 'Please run the script with -h or --help for more information on command line options.'
    
def reportSpaceInOptionValue(csLogger, args):
    msg1= 'The following option value is not correct: \''+ str(args)+ '\'. Please make sure there are no spaces in option values (such as file paths), or that the values are surrounded by double quotes.'
    msg2= 'If you are trying to pass \''+ str(args) + '\' as a part of a list of values, make sure that there are no spaces in or between list elements, or that the entire list is surrounded by double quotes.'
    #print 'ERROR: '+ msg1 
    #print msg2
    csLogger.error(msg1)
    csLogger.info(msg2)
    referToCommandLineHelp()