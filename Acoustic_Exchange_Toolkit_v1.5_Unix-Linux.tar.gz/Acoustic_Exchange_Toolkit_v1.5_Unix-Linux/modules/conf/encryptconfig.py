##################################################################################
#   Copyright (C) 2018, 2020 Acoustic, L.P. All rights reserved.  
#   NOTICE: This file contains material that is confidential and proprietary to
#   Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
#   industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
#   Acoustic, L.P. Any unauthorized copying or distribution of content from this file is prohibited.

##################################################################################
import sys
import os
import traceback
import getopt

from conf import cfg
from conf.cfg import Config

from java.lang import Throwable
from java.lang import IllegalArgumentException
from java.io import File

from com.ibm.emm.integration.log import CSLogger, CSLogStats
from com.ibm.emm.integration.config import ConfigReader
from com.ibm.emm.integration.util import PropertiesCopyHelper
from com.ibm.emm.integration.util import RetriableIOUtils

def EncryptConfig(argv):    
    
    ################
    ## Parsing command line arguments
    ################     
    propertyFilePath = None
    charSetName = None            
    usage = 'Usage: encryptConfig [-f <propertiesFile>] [-e <encoding>]'    
    try:
        opts, args = getopt.gnu_getopt(argv,"hf:e:",["help", "propertiesFile=", "encoding="])
    except getopt.GetoptError:
        print usage
        sys.exit(2)
    if ( (args is not None) and (len(args)> 0) ):
        print 'The following option value is not correct: \''+ args[0]+ '\'. Please make sure there are no spaces in option values (such as file paths), or that the values are surrounded by double quotes.'
        print 'If you are trying to pass \''+ args[0] + '\' as a part of a list of values, make sure that there are no spaces in or between list elements, or that the entire list is surrounded by double quotes.'
        sys.exit(0)
    for opt, arg in opts:        
        if opt in ("-h", "--help"):
            print usage
            sys.exit(0)
        elif opt in ("-f", "--propertiesFile"):
            propertyFilePath = arg          
        elif opt in ("-e", "--encoding"):
            charSetName = arg   

    csLogger = CSLogger.setScript("encryptConfig")        
    csLogger = CSLogger.getCSLogger("scripts.encryptConfig")
    
    try:
        if (charSetName is None):
            charSetName= 'UTF-8'
        if (propertyFilePath is None):
            encryptPropertyFile(cfg.getConfDir()+ os.sep + Config.DEFAULT_CONFIG_FILE, charSetName, csLogger)
            encryptPropertyFile(cfg.getConfDir()+ os.sep + Config.DEFAULT_JDBC_FILE, charSetName, csLogger)       
        else:
            encryptPropertyFile(propertyFilePath, charSetName, csLogger)
    except BaseException:        
        csLogger.fatal('Error has occurred while running Encrypt Configuration script');
        csLogger.info(traceback.format_exc());
        
    except Throwable, e:        
        csLogger.fatal('Error has occurred while running Encrypt Configuration script', e)
        csLogger.info(traceback.format_exc());
    
    finally:
        csLogger.println()
        csLogger.info('Script Run Summary')
        CSLogStats.printSummary(csLogger)
            
   
   
   
def encryptPropertyFile(propertyFilePath, charSetName, csLogger):
    
    propertyFile= File(propertyFilePath)
    if( propertyFile.isAbsolute() ):
        if (not propertyFile.exists()):
            raise IllegalArgumentException('Property file '+ propertyFile.getAbsolutePath()+ ' does not exist')
    else:
        propertyFile= File(cfg.getCLRHome()()+ os.sep +  propertyFilePath)
        if( not propertyFile.exists()):
            raise IllegalArgumentException('Property file '+ propertyFilePath+ ' does not exist in/relatively to CA_HOME directory')
                            
        
    csLogger.info('The property file to be encrypted: '+ propertyFile.getAbsolutePath())       
    csLogger.info('Start encrypting... ');   
    encryptedProps= ConfigReader(propertyFile).recopyEncrypted();
    tmpEncryptedPropertyFile= File(propertyFile.getAbsolutePath()+ '.encrypting_in_process')
    PropertiesCopyHelper.encryptAndCopy(propertyFile, tmpEncryptedPropertyFile,  encryptedProps, charSetName)
    csLogger.info('\tDone encrypting');
    
    csLogger.info('Deleting the original (not encrypted) property file: '+ propertyFile.getAbsolutePath()+ ' ...')
    if( not RetriableIOUtils.delete(propertyFile, 3, 1000) ):
        csLogger.error('Can\'t delete the original property file' )
        return
    csLogger.info('\tDone deleting')
    csLogger.info('Renaming the encrypted property file '+ tmpEncryptedPropertyFile.getName() + ' to have the original file name... ')
    if ( not RetriableIOUtils.rename(tmpEncryptedPropertyFile, propertyFile, 3, 1000) ):
        csLogger.error('Can\'t rename the encrypted property file')
        return        
    csLogger.info('\tDone renaming')
    
    csLogger.info('Done processing '+ propertyFile.getAbsolutePath())
    

   
   

if __name__ == '__main__':    
    EncryptConfig(sys.argv[1:])
