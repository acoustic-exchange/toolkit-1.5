##################################################################################
#   Copyright (C) 2018, 2020 Acoustic, L.P. All rights reserved.  
#   NOTICE: This file contains material that is confidential and proprietary to
#   Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
#   industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
#   Acoustic, L.P. Any unauthorized copying or distribution of content from this file is prohibited.

##################################################################################
import os
import sys
import getopt
import time
import csv

from conf.cfg import getAbsolutePath
from conf.ubxconfig import UBXConfig
from ubx.apimanager import UBXAPIManager
from ubx.segments import *

from com.ibm.emm.integration.log import CSLogger
from java.lang import Exception, Throwable

def PublishSegments(argv):    

    # Parsing command line arguments                
    configPropsFileName = None
    segmentFileName = None   
    usage = 'Usage: publishSegments [-c <config properties file> -f <segmentFile name to be published>]'    
    try:
        opts, args = getopt.getopt(argv,"hc:f:",["config=","segmentFile="])
    except getopt.GetoptError:
        print usage
        sys.exit(64)
    for opt, arg in opts:        
        if opt in ("-c", "--config"):
            configPropsFileName = getAbsolutePath(arg)
        elif opt in ("-f", "--segmentFile"):
            segmentFileName = arg
    
    try:       
        # Initializing, loading configuration, etc.
        csLogger = CSLogger.setScript("publishSegments")
        csLogger = CSLogger.getCSLogger("scripts.publishSegments")        
        config = UBXConfig(configPropsFileName)
        authkey = config.getSegmentProducerAuthenticationKey()
        
        apimanager = UBXAPIManager(config)
        
        hasSegmentsToPublish = False
        segmentPublishDir = config.getSegmentPublishFolder()

        csLogger.info("***** Segment Publish script started. *****") 

        # Get list of current published segments
        currentSegments = apimanager.getSegments(authkey)
        
        segmentFilesPublished = []      
        segmentFiles = []
        
        if(segmentFileName is not None and len(segmentFileName)>0):
            csLogger.info("segmentFileName (or -f) was specified as " + segmentFileName)
            csLogger.info("Will attempt processing only " + segmentFileName)
            segmentFiles.append(segmentFileName)
            
        else:
            csLogger.info("No segmentFileName was specified. Performing a regular publish.")
            segmentFiles = os.listdir(segmentPublishDir)
            
        newSegments = []
        existingSegments = []
        counter=1;
        for segmentFile in segmentFiles:
            segmentFilepath = segmentPublishDir + os.sep + segmentFile
            if os.path.isfile(segmentFilepath): 
                if segmentFile.startswith("UBXSegment_") and segmentFile.endswith(".csv"):                    
                    hasSegmentsToPublish = True
                    
                    filename = os.path.splitext(segmentFile)[0]
                    tokens = filename.split('_')
                    if (len(tokens) != 2):
                        csLogger.info("Skipping file: " + segmentFile)
                    else:
                        segmentName = tokens[1]
                        csLogger.info("Publish Segment: " + segmentName)
                        counter = counter + 1                    
                        segment = findSegmentByName(currentSegments, segmentName)
                        if segment is None:
                            segmentId = int(round(time.time() * 1000)) + (counter)
                            segment = Segment(segmentId, segmentName, None)     
                            newSegments.append(segment)
                        else:
                            existingSegments.append(segment)
                                                       
                        # segment attributes
                        try:  
                            f =  open(segmentFilepath, 'rU')              
                            csvReader = csv.reader(f, delimiter=',')                
                            
                            # Read the first line as headers
                            colHeaders = csvReader.next()
                            csLogger.info("Column headers from file: " + ','.join(colHeaders))
                            for header in colHeaders:
                                segment.addSegmentAttribute(header, "Text")
                        finally:
                            f.close()
                        
                        csLogger.debug("Segment JSON=" + str(segment.toJSON()))   
    
                        segmentFilesPublished.append(segmentFile)
                else:
                    csLogger.info("Skipping file: " + segmentFile)
            else:
                csLogger.warn("Segment file could not be found: " + segmentFilepath)
    
        if (len(newSegments) == 0 and len(existingSegments) == 0):
            csLogger.info("No segments to be published")
        
        if (len(newSegments) > 0):
            csLogger.info("Publishing " + str(len(newSegments)) + " new segments...")
            apimanager.addSegments(newSegments)

        if (len(existingSegments) > 0):
            csLogger.info("Republishing " + str(len(existingSegments)) + " segments...")
            for segment in existingSegments:
                apimanager.deleteSegment(segment.id)            
            apimanager.addSegments(existingSegments)
       
        # move csv files to published folder
        publishedDir = config.getSegmentPublishedFolder()
        for segmentFile in segmentFilesPublished:
            segmentFilepath = segmentPublishDir + os.sep + segmentFile
            destfile = publishedDir + os.sep + segmentFile                                            
            try:
                if (os.path.exists(destfile)):
                    os.remove(destfile)
                os.rename(segmentFilepath, destfile)
            except OSError:
                csLogger.error("Segment producer endpoint ID :" + config.getSegmentProducerEndpointID() + " Error moving file from " + segmentFilepath + " to " + destfile)
        
        csLogger.info("***** Segment Publish script completed successfully. *****")
                                  
    except Throwable, e:
        csLogger.error("Segment producer endpoint ID :" + config.getSegmentProducerEndpointID() + ' Segment Publish script terminating with error!',e)
    
    except BaseException, e:        
        csLogger.error("Segment producer endpoint ID :" + config.getSegmentProducerEndpointID() + ' Segment Publish script terminating with error! Exception type: ' + type(e).__name__ + ', Exception args:' + str(e))
    finally:
        csLogger.info('Segment Publish script completed.')  
        
if __name__ == '__main__':    
    PublishSegments(sys.argv[1:])
