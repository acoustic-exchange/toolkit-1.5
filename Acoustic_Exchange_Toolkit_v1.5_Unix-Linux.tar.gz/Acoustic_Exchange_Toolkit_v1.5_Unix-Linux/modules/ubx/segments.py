##################################################################################
#   Copyright (C) 2018, 2020 Acoustic, L.P. All rights reserved.  
#   NOTICE: This file contains material that is confidential and proprietary to
#   Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
#   industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
#   Acoustic, L.P. Any unauthorized copying or distribution of content from this file is prohibited.

##################################################################################
import simplejson as json

class Segment:
    def __init__(self, id, name, description):        
        self.id = id
        self.name = name
        self.description = description 
        self.segment_attributes = []
    
    def toJSON(self):
        payload = {}
        payload["id"] = self.id
        payload["name"] = self.name
        if (self.description is not None):
            payload["description"] = self.description
               
        attribs = [] 
        for seg_attrib in self.segment_attributes:
            attribs.append(seg_attrib.toJSON())
        payload["segment_attributes"] = attribs
        return payload
    
    def fromJSON(self, payload):
        self.id = payload["id"] 
        self.name = payload["name"]
        self.description = payload["description"]
    
    def addSegmentAttribute(self, name, type):
        self.segment_attributes.append(SegmentAttribute(name, type))
    
class SegmentAttribute:
    def __init__(self, name, type):        
        self.name = name
        self.type = type
    
    def toJSON(self):
        payload = {}
        payload["name"] = self.name
        payload["type"] = self.type
        return (payload)
        
def findSegmentByName(segments, segmentName):
    if (segments is None):
        return None
    for segment in segments:
        if (segment.name == segmentName):
            return segment
    return None

    