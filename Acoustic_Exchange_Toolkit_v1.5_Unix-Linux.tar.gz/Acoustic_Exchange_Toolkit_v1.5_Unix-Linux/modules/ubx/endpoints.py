##################################################################################
#   Copyright (C) 2018, 2020 Acoustic, L.P. All rights reserved.  
#   NOTICE: This file contains material that is confidential and proprietary to
#   Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
#   industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
#   Acoustic, L.P. Any unauthorized copying or distribution of content from this file is prohibited.

##################################################################################
import simplejson as json

class ProducerType:
    PUSH = "push"
    PULL = "pull"

class DestinationType:
    PUSH = "push"
    PULL = "pull"

class Endpoint:
    def __init__(self, name=None, desc=None, providerName=None):
        self.id = None
        self.providerName = providerName        
        self.description = desc
        self.name = name
        self.endpointTypes = None
        self.marketingDatabasesDefinition = None
        
    def toJSON(self):
        payload = {}
        payload["name"] = self.name
        payload["description"] = self.description        
        payload["providerName"] = self.providerName        
        payload["endpointTypes"] = self.endpointTypes.toJSON()
        
        if (self.marketingDatabasesDefinition is not None):
            payload["marketingDatabasesDefinition"] = self.marketingDatabasesDefinition.toJSON()
        
        return json.dumps(payload)
    
    def fromJSON(self, payload):
        self.id = payload["endpointId"] 
        self.name = payload["name"]
        self.description = payload["description"]
        self.providerName = payload["providerName"]         

class EventEndpointType:
    def __init__(self):
        self.event = EventEndpoint() 

    def toJSON(self):
        payload = {}
        payload["event"] = self.event.toJSON()
        return payload

class EventEndpoint:
    def __init__(self):
        self.source = None
        self.destination = None
            
    def toJSON(self):
        payload = {}
        
        if (self.source is not None):
            payload["source"] = self.source.toJSON()
            
        if (self.destination is not None):
            payload["destination"] = self.destination.toJSON()
 
        return payload
    
class EventSource:
    def __init__(self, enabled):
        self.enabled = enabled

    def toJSON(self):
        payload = {}
        payload["enabled"] = self.enabled
        return payload
    
class EventDestination:
    def __init__(self, enabled, destinationType, url):
        self.enabled = enabled
        self.destinationType = destinationType
        self.url = url
           
    def toJSON(self):
        payload = {}
        payload["enabled"] = self.enabled
        if (self.destinationType is not None):
            payload["destinationType"] = self.destinationType
        if (self.url is not None):
            payload["url"] = self.url
        return payload


class SegmentSource:
    def __init__(self, enabled, producerType, url):
        self.enabled = enabled
        self.producerType = producerType
        self.url = url
        self.dataWindow = None
           
    def toJSON(self):
        payload = {}
        payload["enabled"] = self.enabled
        if (self.producerType is not None):
            payload["producerType"] = self.producerType
        if (self.url is not None):
            payload["url"] = self.url
        if (self.dataWindow is not None):
            payload["dataWindow"] = self.dataWindow  
        return payload

class SegmentDestination:
    def __init__(self, enabled, destinationType, url):
        self.enabled = enabled
        self.destinationType = destinationType
        self.url = url
           
    def toJSON(self):
        payload = {}
        payload["enabled"] = self.enabled
        if (self.destinationType is not None):
            payload["destinationType"] = self.destinationType
        if (self.url is not None):
            payload["url"] = self.url
        return payload
    
class SegmentEndpointType:
    def __init__(self):
        self.segment = SegmentEndpoint() 

    def toJSON(self):
        payload = {}
        payload["segment"] = self.segment.toJSON()
        return payload

class SegmentEndpoint:
    def __init__(self):
        self.source = None
        self.destination = None
            
    def toJSON(self):
        payload = {}
        
        if (self.source is not None):
            payload["source"] = self.source.toJSON()
            
        if (self.destination is not None):
            payload["destination"] = self.destination.toJSON()
 
        return payload
    
class MarketingDatabasesDefinition:
    def __init__(self):
        self.marketingDatabases = []
    
    def toJSON(self):
        payload = {}  
        dbs = [] 
        for db in self.marketingDatabases:
            dbs.append(db.toJSON())
        payload["marketingDatabases"] = dbs
        return payload
    

class MarketingDatabase:
    def __init__(self):
        self.id = None
        self.name = None
        self.identifiers = []
        self.attributes=[]
    
    def toJSON(self):
        payload = {}        
        payload["name"] = self.name

        idents = [] 
        for ident in self.identifiers:
            idents.append(ident.toJSON())
        payload["identifiers"] = idents
        
        attribs = [] 
        for attrib in self.attributes:
            attribs.append(attrib.toJSON())
        payload["attributes"] = attribs
        return payload

class MarketingDatabaseIdentifier:
    def __init__(self,name,type):
        self.name = name
        self.type = type
        self.hashMode = None
        self.hashAlgorithm = None
        self.isRequired = False
    
    def toJSON(self):
        payload = {}        
        payload["name"] = self.name
        payload["type"] = self.type
        payload["hashMode"] = self.hashMode
        payload["isRequired"] = self.isRequired
        return payload

class MarketingDatabaseAttribute:
    def __init__(self,name,type):
        self.name = name
        self.type = type
        self.hashMode = None
        self.hashAlgorithm = None
        self.isRequired = False
    
    def toJSON(self):
        payload = {}        
        payload["name"] = self.name
        payload["type"] = self.type
        payload["hashMode"] = self.hashMode
        payload["isRequired"] = self.isRequired
        return payload
         