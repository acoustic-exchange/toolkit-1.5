##################################################################################
#   Copyright (C) 2018, 2020 Acoustic, L.P. All rights reserved.  
#   NOTICE: This file contains material that is confidential and proprietary to
#   Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
#   industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
#   Acoustic, L.P. Any unauthorized copying or distribution of content from this file is prohibited.

##################################################################################
import simplejson as json

class JobCategory:
    SEGMENT_EXPORT = "SEGMENT_EXPORT"
    IDENTITIES_UPLOAD = "IDENTITIES_UPLOAD"
    
class JobStatus:
    WAITING_TO_RECIEVE_DATA = "WAITING_TO_RECIEVE_DATA"
    READY_FOR_DOWNLOAD = "READY_FOR_DOWNLOAD"
    COMPLETE = "COMPLETE"
    
class Job:    
    def __init__(self):        
        self.jobId = None
        self.jobName = None
        self.jobCategory = None
        self.status = None
        self.subStatus = None
        self.segmentDataFiles = []
        self.segmentDataFormat = None 
        self.destinationSegmentID = None
        destinationSegmentName = None
        destinationSegmentDescription = None
        destinationEndpointID = None
        exportCategory = None
        producerEndpointID = None
        producerSegmentID = None
        started = None
        attributeMappings = []
        identityMappings = []
        
    def toJSON(self):
        payload = {}
        payload["jobId"] = self.jobId
        payload["jobName"] = self.jobName
        payload["jobCategory"] = self.jobCategory
        payload["status"] = self.status
        payload["subStatus"] = self.subStatus
        payload["accountId"] = self.accountId
        payload["segmentDataFiles"] = self.segmentDataFiles 
        payload["segmentDataFormat"] = self.segmentDataFormat        
        payload["destinationSegmentID"] = self.destinationSegmentID
        payload["destinationSegmentName"] = self.destinationSegmentName
        payload["destinationSegmentDescription"] = self.destinationSegmentDescription
        payload["destinationEndpointID"] = self.destinationEndpointID
        payload["exportCategory"] = self.exportCategory
        payload["producerEndpointID"] = self.producerEndpointID
        payload["producerSegmentID"] = self.producerSegmentID
        payload["attributeMappings"] = self.attributeMappings
        payload["identityMappings"] = self.identityMappings
        payload["started"] = self.started
        
        return payload
    
    def fromJSON(self, payload):
        self.jobId = payload["jobId"]
        self.jobName = payload["jobName"]
        self.jobCategory = payload["jobCategory"]
        self.status = payload["status"]
        self.subStatus = payload["subStatus"]
        self.accountId = payload["accountId"]
        self.segmentDataFiles = payload["segmentDataFiles"]
        self.segmentDataFormat = payload["segmentDataFormat"]          
        self.destinationSegmentID = payload["destinationSegmentID"] 
        self.destinationSegmentName = payload["destinationSegmentName"] 
        self.destinationSegmentDescription = payload["destinationSegmentDescription"] 
        self.destinationEndpointID = payload["destinationEndpointID"] 
        self.exportCategory = payload["exportCategory"] 
        self.producerEndpointID = payload["producerEndpointID"] 
        self.producerSegmentID = payload["producerSegmentID"]
        self.attributeMappings = payload["attributeMappings"]
        self.identityMappings = payload["identityMappings"]
        if(payload.has_key("started")):
            self.started = payload["started"]  

        