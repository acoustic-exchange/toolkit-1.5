##################################################################################
#   Copyright (C) 2018, 2020 Acoustic, L.P. All rights reserved.  
#   NOTICE: This file contains material that is confidential and proprietary to
#   Acoustic, L.P. and/or other developers. No license is granted under any intellectual or
#   industrial property rights of Acoustic, L.P. except as may be provided in an agreement with
#   Acoustic, L.P. Any unauthorized copying or distribution of content from this file is prohibited.
##################################################################################
import os
import sys
import getopt
import traceback
import codecs

from conf.cfg import Config, getAbsolutePath, getAppDataDir
from conf.ubxconfig import UBXConfig
from ubx.apimanager import UBXAPIManager
from java.lang import Exception
from java.lang import Throwable
from java.text import SimpleDateFormat

from com.ibm.emm.integration.log import CSLogger, CSLogStats
from com.ibm.emm.integration.util import NormalizeUtils
from com.ibm.emm.integration.ubx import EventDataReader, EventDataWriter

def EventsDownload(argv):    

    # Parsing command line arguments                
    configPropsFileName = None
    format = "tsv"
    downloadFileCount = 0
       
    usage = 'Usage: eventsDownload [-c <config properties file>]'    
    try:
        opts, args = getopt.getopt(argv,"hc:",["config="])
    except getopt.GetoptError:
        print usage
        sys.exit(64)
    for opt, arg in opts:        
        if opt in ("-c", "--config"):
            configPropsFileName = getAbsolutePath(arg)
        elif opt in ("-h"):
            print usage
            sys.exit(0)

    exitStatusCode = 0

    try:
        # Initializing, loading configuration, etc.
        csLogger = CSLogger.setScript("createTsv")
        csLogger = CSLogger.getCSLogger("scripts.createTsv")        
        config = UBXConfig(configPropsFileName)
        downloadDir = config.getLocalDownloadDir() + "/"
        if not os.path.exists(downloadDir):
            os.makedirs(downloadDir) 

        encoding = config.getEncoding()

        csLogger.info('Creating tsv files...')  
        for filename in os.listdir(downloadDir):
            if os.path.isfile(os.path.join(downloadDir, filename)):
                # translate json file to tsv
                f = open(os.path.join(downloadDir, filename), "r")
                ucontent = f.read()
                print ucontent

                if (encoding is not None):                 
                    pencoding = encoding.lower()
                    csLogger.info("JSON file encoding is: " + pencoding)   
                    
                    ucontent = unicode(ucontent, pencoding)
                    
                tsvFilePath = downloadDir + filename + ".tsv"
                
                
                eventDataReader = EventDataReader()
                if (encoding is not None):
                    eventDataReader.setEncoding(encoding)
                    
                eventDataList = eventDataReader.readEventsFromString(ucontent)
                print eventDataList
                eventDataWriter = EventDataWriter()
                if (encoding is not None):
                    eventDataWriter.setEncoding(encoding)
                csLogger.info('Saving events to: ' + tsvFilePath)
                
                toolkitSeparator = config.getToolkitSeparator()

                csLogger.info('toolkitSeparator: ' + toolkitSeparator)
                
                eventDataWriter.setToolkitSeparator(toolkitSeparator)
                
                eventDataWriter.writeTSVFile(eventDataList, tsvFilePath)
                
                if (not os.path.exists(tsvFilePath)):
                    csLogger.error("Error saving events to file: " + tsvFilePath)
                    shouldDeleteFileFromServer = False
                    getMoreFiles = False
        
    except Exception, e:
        csLogger.error('EventsDownload script terminating with error!', e)
        exitStatusCode = 64
        
    finally:
        csLogger.println()
        csLogger.info('EventsDownload Script Run Summary')
        csLogger.info('Event files downloaded: ' + str(downloadFileCount))
        CSLogStats.printSummary(csLogger)
        csLogger.info("***** Download Events script completed. *****")
        sys.exit(exitStatusCode)

if __name__ == '__main__':    
    EventsDownload(sys.argv[1:])
